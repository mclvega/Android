package com.example.garson

class Orden(val id:Int,val nombre:String,val mesa:Byte,val estado:String) {
}