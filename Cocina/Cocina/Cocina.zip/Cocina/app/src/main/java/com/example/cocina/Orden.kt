package com.example.cocina

class Orden(val id:Int,val nombre:String,val mesa:Byte,val estado:String) {
}